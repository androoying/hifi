/******************************************************************************

 @File         PVRTextureVersion.h

 @Title        

 @Version      

 @Copyright    Copyright (c) Imagination Technologies Limited. All Rights Reserved. Strictly Confidential.

 @Platform     ANSI

 @Description  Texture processing routines.

******************************************************************************/
#ifndef PVRTEXLIBVERSION_H
#define PVRTEXLIBVERSION_H
#define PVRTLMAJORVERSION 4
#define PVRTLMINORVERSION 2
#define PVRTLSTRINGVERSION "4.2"
#define PVRTLVERSIONDESCRIPTOR "" //"BETA" //"ALPHA" //"ENGINEERING DROP"
#endif

