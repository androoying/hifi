// This code is in the public domain -- castanyo@yahoo.es

#include "Vector.h"
#include "Vector.inl"
