// This code is in the public domain -- castanyo@yahoo.es

#include "Color.h"
#include "Color.inl"
