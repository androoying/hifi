#ifndef _LUA_PHYSICS_SETUP_H
#define _LUA_PHYSICS_SETUP_H

class CommonExampleInterface* LuaDemoCreateFunc(struct CommonExampleOptions& options);

#endif  //_LUA_PHYSICS_SETUP_H
