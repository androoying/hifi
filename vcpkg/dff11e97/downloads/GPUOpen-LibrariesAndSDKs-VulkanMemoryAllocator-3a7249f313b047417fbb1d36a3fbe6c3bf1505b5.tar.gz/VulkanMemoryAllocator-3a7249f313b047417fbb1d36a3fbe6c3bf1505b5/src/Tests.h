#ifndef TESTS_H_
#define TESTS_H_

#ifdef _WIN32

void Test();

#endif // #ifdef _WIN32

#endif
