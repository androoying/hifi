var searchData=
[
  ['record_20and_20replay',['Record and replay',['../record_and_replay.html',1,'index']]],
  ['requiredflags',['requiredFlags',['../struct_vma_allocation_create_info.html#a9166390303ff42d783305bc31c2b6b90',1,'VmaAllocationCreateInfo']]],
  ['recommended_20usage_20patterns',['Recommended usage patterns',['../usage_patterns.html',1,'index']]]
];
