var searchData=
[
  ['record_20and_20replay',['Record and replay',['../record_and_replay.html',1,'index']]],
  ['recommended_20usage_20patterns',['Recommended usage patterns',['../usage_patterns.html',1,'index']]]
];
