var searchData=
[
  ['choosing_20memory_20type',['Choosing memory type',['../choosing_memory_type.html',1,'index']]],
  ['configuration',['Configuration',['../configuration.html',1,'index']]],
  ['custom_20memory_20pools',['Custom memory pools',['../custom_memory_pools.html',1,'index']]]
];
