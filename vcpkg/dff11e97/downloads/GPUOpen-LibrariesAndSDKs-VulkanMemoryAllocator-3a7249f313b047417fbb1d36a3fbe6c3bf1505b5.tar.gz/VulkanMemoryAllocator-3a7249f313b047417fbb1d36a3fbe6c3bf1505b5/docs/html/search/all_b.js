var searchData=
[
  ['quick_20start',['Quick start',['../quick_start.html',1,'index']]]
];
